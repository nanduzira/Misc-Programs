#!/bin/bash 
    

zip -r 8086.zip 8086 
   while read ip; 
do 
sshpass -p 'itims181' scp 8086.zip root@$ip:/home/student < /dev/null;
sshpass -p 'itims181' ssh root@$ip unzip /home/student/8086.zip -d /home/student/ < /dev/null;
sshpass -p 'itims181' ssh root@$ip chmod -R 777 /home/student/8086 < /dev/null;
echo "Finished" $ip

done < ipaddress.txt
