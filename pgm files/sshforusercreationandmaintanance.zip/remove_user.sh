#!/bin/bash 
    
   while read ip; 
do 
sshpass -p 'itims181' ssh root@$ip:/home/ < /dev/null;
sshpass -p 'itims181' ssh root@$ip rm -rf student < /dev/null;
sshpass -p 'itims181' ssh root@$ip rm -rf Exam < /dev/null;
echo "Finished" $ip

done < ipaddress1.txt
