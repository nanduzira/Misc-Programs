#!/bin/bash 
   while read ip; 
do 
	echo "Pendrive UnBlocking on" $ip
   sshpass -p 'itims181' ssh root@$ip sudo chmod 000 /media < /dev/null;
sshpass -p 'itims181' ssh root@$ip sudo chmod 000 /home/s7cse < /dev/null;

   sshpass -p 'itims181' ssh root@$ip usermod -L s7cse < /dev/null;
   sshpass -p 'itims181' ssh root@$ip usermod -U Exam < /dev/null;
 
 echo "Finished" $ip
done < ipaddress1.txt
